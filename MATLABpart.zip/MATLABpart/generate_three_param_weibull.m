function weibull_random_numbers = generate_three_param_weibull(alpha, beta, gamma, n)
    rng('shuffle');
    two_param_weibull = wblrnd(beta, alpha, n, 1);
    weibull_random_numbers = two_param_weibull + gamma;
end