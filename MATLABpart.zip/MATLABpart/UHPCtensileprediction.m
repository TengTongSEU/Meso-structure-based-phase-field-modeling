clear;clc;
% *********************************************************************
% distribution parameters of weibull
alpha = 5.2; 
beta = 4.9; 
gamma = 7.25;
n =46; 
L=10;
sigmamu = generate_three_param_weibull(alpha, beta, gamma, n);
% *********************************************************************

% fracture strength
% *********************************************************************
f=1.4; 
kappa=0.8;
p=0.75;q=0.75;
ytheta=@(x) (sin(x)).^(2.*p-1).*(cos(x)).^(2.*q-1);
ptheta= integral(ytheta, 0, pi/2);
fg=@(theta) 2*exp(f*theta).*(cos(theta)).^(kappa+1).*(sin(theta)).^(2.*p-1).*(cos(theta)).^(2.*q-1)./ptheta;
gjia= 2*integral(fg, 0, pi/2);
vf=0.01;  % volume fraciton of fiber
Ef=200000;
vm=1-vf;  %volume fraciton of matrix
Em=53000;
eta=(vf*Ef)/(vm*Em);
% sigma0
tau0=10.8;% input the frictional sliding shear stress when no slip occurs
taur=0.1*tau0;
Lf=13;
df=0.2;
sigma01=0.5*gjia *vf*(1+eta)*Lf/df;
sigma0=0.5*gjia *tau0*vf*(1+eta)*Lf/df;%initial fiber pullout stress
c=5;%input radius of the crack
muc=0.2;  %Poisson’s ratio of the composite
Ec=56000;   % elastic modulus of the composite
beta=0.3;  % nondimensional softening parameter
deltam=8*c*(1-(muc)^2)/(pi*Ec)*sigmamu;
omega=((4*(1+eta)*beta*tau0)/Ef)^0.5;
k=sqrt(2)*(omega*Lf)/(4*df);
zeta=(beta*Lf)/(4*df);
deltaNxing=2*log(cosh(k))/zeta;
deltaxing=deltaNxing*Lf/2;
etaf=1.1;
sigmafc=sigmamu+1/2*(sigma0*(8/3*(deltam/deltaxing).^0.5-deltam/deltaxing))/etaf; % fracture strength
xd=1/2*(Lf-(Lf^2-(2*sigmamu.*Lf*vm*df)/(gjia*tau0*vf)).^0.5); %he stress transfer distance
% process of loading
% *********************************************************************
sigmafcmin = min(sigmafc(:));%
nc=2.7;
crack=zeros(n,1); 
stress=zeros(5000,1);
strain=zeros(5000,1);
stress(2)=sigmafcmin;
strain(2)=sigmafcmin/Ec;
sBN = @(xdNjia) (tau0-taur)*...
    (2/k*(1-1/k*acosh(exp(0.5*zeta*xdNjia)))*sqrt(1-exp(-zeta*xdNjia))+exp(-2*zeta*xdNjia)*(-2*xdNjia*(1-(1-1/k*acosh(exp(0.5*zeta*xdNjia))))+ (1-(1-1/k*acosh(exp(0.5*zeta*xdNjia))))^2+2*k^2/3/zeta*(1-2*zeta*xdNjia)*(1-(1-1/k*acosh(exp(0.5*zeta*xdNjia))))^3+5*k^2/6*(1-(1-1/k*acosh(exp(0.5*zeta*xdNjia))))^4))+...
    taur*...
    (2*((1-1/k*acosh(exp(0.5*zeta*xdNjia)))-xdNjia)*(1-(1-1/k*acosh(exp(0.5*zeta*xdNjia))))+(1-(1-1/k*acosh(exp(0.5*zeta*xdNjia))))^2+ 2*k^2/3/zeta*(1-(1-1/k*acosh(exp(0.5*zeta*xdNjia))))^3);
sBNxz=@(xdNjia) (tau0-taur)*...
    exp(-2*zeta*xdNjia)*((1-xdNjia)^2+2*k^2/3/zeta*(1-2*zeta*xdNjia)+5*k^2/6)...
    + taur*((1-xdNjia)^2+2*k^2/3/zeta*((1-xdNjia)^3));
c =sigmafcmin/sigma01;
fjia = @(xdNjia) sBN(xdNjia) - c;
options = optimoptions('fsolve', 'Display', 'iter', 'FunctionTolerance', 1e-5,'StepTolerance', 1e-5);
x0 = 0.003; 
[xdNjia, fval, exitflag, output] = fsolve(fjia, x0, options);
deltaN=xdNjia;
ijuzhen=3;
while deltaN<=0.1
    delta=deltaN*Lf/2;
    if deltaN<=deltaNxing
        sigma=sBN(deltaN)*sigma01;
        i = 1; % section number
        while i <= n
            if crack(i)==0
                if  sigma>=sigmafc(i)
                    newcrack=0;
                    for j=-fix(xd(i)):fix(xd(i)) 
                        if (i+j) >= 1 && (i+j) <= n 
                            newcrack=newcrack+crack(i+j);
                        end
                    end
                    if newcrack==0
                        crack(i)=1;
                    end
                end
            end
            i=i+1;
        end
        N=sum(sum(crack));
        deltac=N/nc*delta;
        deltaNstep=0.0001;
        deltapeak=delta;
    else
        sigma=sBNxz(deltaN)*sigma01;
        deltac=N/nc*deltapeak+(delta-deltapeak);
        deltaNstep=0.001;
    end
    sigmaBN(ijuzhen)=sBNxz(deltaN);
    deltaBN(ijuzhen)=deltac;
    strain(ijuzhen)=sigma/Ec+ deltac/L;
    stress(ijuzhen)=sigma;
    deltaN= deltaN+deltaNstep;
    ijuzhen=ijuzhen+1;
end
strain=strain(1:ijuzhen-1);
stress=stress(1:ijuzhen-1);
sigmaBN=sigmaBN';
deltaBN=deltaBN';
pstrain=strain*100;
plot(strain*100,stress,'b');
grid on;
xlabel('strain（%）');
ylabel('stress（Mpa)'); 
title('UHPC tensile stress-strain curve'); 